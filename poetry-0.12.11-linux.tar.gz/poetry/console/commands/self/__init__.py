from .update import SelfUpdateCommand
