from .info import DebugInfoCommand
from .resolve import DebugResolveCommand
